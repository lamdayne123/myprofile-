import { NextResponse } from "next/server";
import { getServerStatus } from "@/lib/server-api";

export const dynamic="force-dynamic";

export async function GET(){
  try{
    const status=await getServerStatus();
    return NextResponse.json(status,{headers:{"Cache-Control":"public, s-maxage=20, stale-while-revalidate=40"}});
  }catch(error){
    console.error("Server status error:",error);
    return NextResponse.json({
      online:false,players:0,maxPlayers:0,tps:null,ping:null,version:null,motd:null,uptime:null,
      checkedAt:new Date().toISOString()
    },{status:200,headers:{"Cache-Control":"public, s-maxage=10"}});
  }
}
