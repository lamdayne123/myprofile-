# Trương Chí Lâm Profile

Complete starter combining the visual profile UI with a server-side Minecraft status API proxy.

## Run
1. Copy `.env.example` to `.env.local`
2. Set `SERVER_STATUS_API_URL`
3. Optionally set `SERVER_STATUS_API_KEY`
4. `npm install`
5. `npm run dev`

Test the normalized endpoint at `/api/server`.

## API flow
Browser -> Next.js `/api/server` -> private upstream API -> normalized server JSON -> Server Status card.

The API key stays server-side. Client polling is 30 seconds and the upstream response uses a short revalidation cache.

## Upstream response
The adapter understands:
`online`, `status`, `players.online`, `players.max`, `playerCount`, `playersOnline`, `maxPlayers`, `playerMax`, `tps`, `TPS`, `ping`, `latency`, `version`, `minecraftVersion`, `motd`, `uptime`.

For a custom API shape, edit `normalizeServerStatus()` in `lib/server-api.ts`.

## Assets
Put your chosen background at `public/images/background.jpg`.
Put real audio files in `public/music/` matching the names in `data/music.ts`.
Replace project/gallery gradients with your own optimized WebP/AVIF images.
